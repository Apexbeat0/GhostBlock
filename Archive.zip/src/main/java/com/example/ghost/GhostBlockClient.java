package com.example.ghost;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.jetbrains.annotations.Nullable;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

/**
 * Client-side only "ghost block" tool.
 *
 * /ghost            -> hides the block you are looking at (client side only)
 * /ghost <range>    -> same, but with a custom raycast distance
 * /ghost restore    -> brings back the last hidden block
 * /ghost clear      -> brings back every hidden block
 *
 * Nothing is sent to the server: only your own client's copy of the world is edited.
 *
 * /dmace                 -> shows the current Mace smash-attack damage multiplier
 * /dmace <multiplier>    -> sets it (1.0 = vanilla, 2.0 = double smash damage, etc.)
 * /dmace reset           -> back to 1.0 (vanilla)
 *
 * NOTE: the multiplier is read by MaceDamageMixin, which patches
 * MaceItem#getAttackDamageBonus. That method runs on the LOGICAL SERVER.
 * In singleplayer the integrated server shares this JVM, so it works there.
 * On a remote multiplayer server, that server does the damage math with its
 * own (unmodified) copy of the game, so this setting has no real effect there.
 */
public class GhostBlockClient implements ClientModInitializer {

    /** Positions we hid, mapped to the state they had before. Insertion ordered. */
    private static final Map<BlockPos, BlockState> HIDDEN = new LinkedHashMap<>();

    /** Multiplier applied to the Mace's fall-distance smash damage bonus. 1.0 = vanilla. */
    private static volatile float maceDamageMultiplier = 1.0F;

    /** Read by {@link com.example.ghost.mixin.MaceDamageMixin}. */
    public static float getMaceDamageMultiplier() {
        return maceDamageMultiplier;
    }

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("ghost")
                    .executes(ctx -> hide(ctx.getSource(), -1.0D))
                    .then(literal("restore")
                            .executes(ctx -> restoreLast(ctx.getSource())))
                    .then(literal("clear")
                            .executes(ctx -> restoreAll(ctx.getSource())))
                    .then(argument("range", DoubleArgumentType.doubleArg(1.0D, 128.0D))
                            .executes(ctx -> hide(ctx.getSource(),
                                    DoubleArgumentType.getDouble(ctx, "range")))));

            dispatcher.register(literal("dmace")
                    .executes(ctx -> showMaceMultiplier(ctx.getSource()))
                    .then(literal("reset")
                            .executes(ctx -> setMaceMultiplier(ctx.getSource(), 1.0F)))
                    .then(argument("multiplier", DoubleArgumentType.doubleArg(0.0D, 1000.0D))
                            .executes(ctx -> setMaceMultiplier(ctx.getSource(),
                                    (float) DoubleArgumentType.getDouble(ctx, "multiplier")))));
        });
    }

    private static int showMaceMultiplier(FabricClientCommandSource source) {
        source.sendFeedback(Component.literal(
                "§7Mace smash-damage multiplier: §f" + maceDamageMultiplier + "x"));
        return 1;
    }

    private static int setMaceMultiplier(FabricClientCommandSource source, float multiplier) {
        maceDamageMultiplier = multiplier;
        source.sendFeedback(Component.literal(
                "§7Mace smash-damage multiplier set to §f" + multiplier + "x"
                        + (multiplier == 1.0F ? " §7(vanilla)" : "")));
        return 1;
    }

    private static int hide(FabricClientCommandSource source, double range) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            return 0;
        }

        // range < 0 -> use the crosshair target the game already calculated this frame
        HitResult hit = range < 0
                ? mc.hitResult
                : mc.player.pick(range, 1.0F, false);

        if (!(hit instanceof BlockHitResult blockHit) || hit.getType() != HitResult.Type.BLOCK) {
            source.sendFeedback(Component.literal("§cNo block in sight."));
            return 0;
        }

        BlockPos pos = blockHit.getBlockPos().immutable();
        BlockState old = mc.level.getBlockState(pos);

        if (old.isAir()) {
            source.sendFeedback(Component.literal("§cThat position is already empty."));
            return 0;
        }

        // Remember the real state so we can put it back later.
        HIDDEN.putIfAbsent(pos, old);

        // Client-only edit: ClientLevel#setBlock marks the chunk section for re-render.
        mc.level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);

        source.sendFeedback(Component.literal(
                "§7Hidden §f" + old.getBlock().getName().getString()
                        + " §7at §f" + pos.getX() + " " + pos.getY() + " " + pos.getZ()));
        return 1;
    }

    private static int restoreLast(FabricClientCommandSource source) {
        if (HIDDEN.isEmpty()) {
            source.sendFeedback(Component.literal("§cNothing to restore."));
            return 0;
        }

        BlockPos last = null;
        for (BlockPos pos : HIDDEN.keySet()) {
            last = pos; // LinkedHashMap keeps insertion order, so this ends on the newest entry
        }

        BlockState state = HIDDEN.remove(last);
        applyBack(last, state);
        source.sendFeedback(Component.literal("§7Restored one block."));
        return 1;
    }

    private static int restoreAll(FabricClientCommandSource source) {
        int count = HIDDEN.size();
        HIDDEN.forEach(GhostBlockClient::applyBack);
        HIDDEN.clear();
        source.sendFeedback(Component.literal("§7Restored " + count + " block(s)."));
        return count;
    }

    private static void applyBack(BlockPos pos, BlockState state) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.level.isLoaded(pos)) {
            mc.level.setBlock(pos, state, Block.UPDATE_ALL);
        }
    }
}
